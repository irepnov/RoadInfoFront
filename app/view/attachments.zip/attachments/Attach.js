Ext.define("roadInfo.view.attachments.Attach", {
    extend: Ext.window.Window,
    alias: "widget.attach",
    title: "Документы",
    id: "attach",
    layout: "fit",
    config: {
      object: null
    },
    width: 600,
    height: 400,
    modal: true,
    maximizable: true,
    collapsible: false,
    border: 0,
    iconAlign: "left",
    iconCls: 'attach16',
    requires: [
        'roadInfo.view.attachments.AttachController',
        'roadInfo.view.attachments.AttachVType'
    ],
    controller: 'attachcontroller',
    defaults: {
        border: 0
    },
    initComponent: function() {
       /* var me = this;

        this.arrObjects = new Ext.data.Store({
            storeId: 'objectsstore',
            autoLoad: true,
            proxy: {
                type: 'ajax',
                url: ProxyUrlBackend + '/objects/?munobr_id=[0]&not_include_all=1',
                withCredentials: true,
                useDefaultXhrHeader: false,
                reader: new Ext.data.JsonReader({
                        type: 'json',
                        rootProperty: 'data',
                        totalProperty: 'totalcount'
                    }, [
                     {name: 'id', type: 'int'}
                    ,{name: 'name', type: 'string'}
                    ,{name: 'munobr', type: 'string'}
                    ,{name: 'munobr_id', type: 'auto'}
                    ,{name: 'km_beg', type: 'float'}
                    ,{name: 'km_end', type: 'float'}
                    ]
                )
            },
            listeners:{
                load: function () {
                    var c = Ext.getCmp('attachComboObject');
                    if (!c || !me) return;
                    c.setValue(me.objectId);
                }
            }
        });*/

        this.items = [
                {
                    xtype: 'form',
                    reference: 'panelattachform',
                    layout: {
                        type: 'vbox',
                        align: 'stretch'
                    },
                    border: 0,

                    padding: '5px',
                    waitMsgTarget: 'Выполняется длительный процесс..',
                    waitTitle: 'Ожидайте',
                    items: [
                        {
                            xtype: 'combo',
                            reference: 'attachobject',
                            id: 'attachobject',
                            name: 'attachobject',
                            fieldLabel: 'Объект содержания',
                            labelWidth: 150,
                            store: 'RefObjectsAll',
                            queryMode: 'local',
                            forceSelection: false,
                            allowBlanc: false,
                            displayField: 'name',
                            valueField: 'id'
                        },
                        {
                            xtype: 'hiddenfield',
                            name: 'attachfileid',
                            id: 'attachfileid',
                            reference: 'attachfileid'
                        },
                        {
                            xtype: 'textareafield',
                            fieldLabel: 'Описание',
                            labelWidth: 150,
                            name: 'attachdesc',
                            id: 'attachdesc',
                            reference: 'attachdesc',
                            allowBlanc: false,
                            height: '100px'
                        },
                        {
                            xtype: 'filefield',
                            name: 'attachfile',
                            id: 'attachfile',
                            reference: 'attachfile',
                            fieldLabel: 'Архив (.zip)',
                            clearOnSubmit: false,
                            allowBlanc: false,
                            labelWidth: 150,
                            vtype: 'mime'
                        }
                    ],
                    buttons: [{
                        text: "Сохранить",
                        tooltip: "Сохранить документ",
                        // disabled: true,
                        action: "save",
                        iconCls: "save16"
                    }]
                }
        ];
        this.callParent(arguments);
    }

});