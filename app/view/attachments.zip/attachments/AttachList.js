Ext.define("roadInfo.view.attachments.AttachList", {
    extend: Ext.window.Window,
    alias: "widget.attachlist",
    title: "Документы",
    id: "attachlist",
    layout: "fit",
    width: 1000,
    height: 500,
    modal: true,
    maximizable: true,
    collapsible: false,
    border: 0,
    iconAlign: "left",
    iconCls: 'attach16',
    requires: [
        'roadInfo.view.attachments.AttachListController',
        'roadInfo.view.attachments.Attach'
    ],
    controller: 'attachlistcontroller',
    defaults: {
        border: 0
    },
    initComponent: function () {
        this.tbar = {
            xtype: "toolbar",
            enableOverflow: true,
            defaults: {
                iconAlign: "top",
                scale: "small"
            },
            items: [
                //{xtype: "tbseparator"},
                {
                    text: "Добавить",
                    tooltip: "Добавить документ",
                    action: "add",
                    iconCls: "add16"
                }, {
                    text: "Изменить",
                    tooltip: "Изменить документ",
                    action: "edit",
                    iconCls: "edit16"
                }, {
                    text: "Удалить",
                    tooltip: "Удалить документ",
                    action: "del",
                    iconCls: "del16"
                }, {
                    xtype: "tbfill"
                },
                {
                    text: "Экспорт",
                    tooltip: "Экспорт ведомости в XLS",
                    action: "xls-export",
                    iconCls: "excel16"
                }, {
                    text: "Скачать",
                    tooltip: "Скачать документ",
                    action: "download",
                    iconCls: "downl16"
                }]
        };
        this.items = [{
            xtype: 'grid',
            reference: 'attachlistgrid',
            id: 'attachlistgrid',
            autoScroll: true,
            store: 'RefAttachList',
            plugins: [{
                ptype: 'rowediting',
                pluginId: 'RowEditingPlugin',
                clicksToEdit: 2,
                listeners: {
                    edit: 'onGridEditorEdit',
                    canceledit: 'onGridEditorCancelEdit'
                }
            }],
            columns: [
                {dataIndex: 'id', text: 'id'}
                , {
                    dataIndex: 'mime', text: 'mime', editor: {
                        xtype: "textfield"
                    }
                }
                , {
                    dataIndex: 'name', text: 'name file', editor: {
                        xtype: "filefield"
                    }
                }
            ]
        }];
        this.callParent(arguments);
    }

});