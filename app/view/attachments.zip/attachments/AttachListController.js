Ext.define('roadInfo.view.attachments.AttachListController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.attachlistcontroller',

    init: function() {
        // this.getView().on("afterlayout", this.onAfterLayout(), this); //либо так

         this.control({
             "attachlist button[action=add]": {
                 click: this.onAddClick
             }
           /*  "attachlist button[action=edit]": {
                 click: this.onEditClick
             },
             "attachlist button[action=del]": {
                 click: this.onDelClick
             },
             "attachlist button[action=download]": {
                 click: this.onDownloadClick
             },
             "attachlist button[action=xls-export]": {
                 click: this.onExportExcelButton
             }*/
         })
    },

    onGridEditorEdit: function (editor, ctx, eOpts) {
        //ctx.grid.getStore().sync();

       /* var grid = this.up('grid'),
            cellediting = grid.findPlugin('cellediting'),
            editors = cellediting.editors,
            editor = editors.getByKey(this.id);*/

        var fileEl = ctx.column.getEditor().fileInputEl,
            file = fileEl.dom.files[0],
            data = new FormData();

        data.append('file', file);
        data.append('test',"sdfsfsf");

        Ext.Ajax.request({
            url: ProxyUrlBackend + "/test/create/",
            rawData: data,
            headers: {'Content-Type':null}, //to use content type of FormData
            success: function(response){ }
        });

    },

    onGridEditorCancelEdit: function (editor, ctx, eOpts) {
        ctx.grid.getStore().rejectChanges();
    },

    onAddClick: function (button, evt) {
        var layergrid = this.lookupReference('attachlistgrid');
        if (layergrid && layergrid.getStore().isLoaded()) {
            var cdef = roadInfo.app.getController('default'),
                objectSelected = cdef.getSelectedMode().objectSelected;
            var newRec = Ext.create('roadInfo.model._RefTest', {});
            layergrid.getStore().insert(0, newRec);
            layergrid.getPlugin('RowEditingPlugin').startEdit(newRec);
        }
    }

    // onExportExcelButton: function () {
    //     //  alert(this.getView().getFields());
    //     var a = this.lookupReference('attachlistgrid');
    //     if (a.getStore().getCount()) {
    //         a.downloadExcelXml(false, this.getView().getTitle())
    //     }
    // },
    //
    // onAddClick: function () {
    //     if (this.attach) {
    //         this.attach.close();
    //         this.attach = null;
    //     }
    //     if (!this.attach) {
    //         var me = this;
    //         var store = Ext.getStore('RefObjectsAll'); //глобальное хранилище, содержащее данные ведомости
    //         if (!store) return;
    //         if (store.isLoaded()){
    //             me.attach = Ext.widget("attach");
    //             me.attach.setTitle("Прикрепить документ");
    //             me.attach.show();
    //         }else {
    //             store.load({
    //                 callback: function () {
    //                     me.attach = Ext.widget("attach");
    //                     me.attach.setTitle("Прикрепить документ");
    //                     me.attach.show();
    //                 }
    //             });
    //         }
    //     }
    // },
    //
    // onEditClick: function () {
    //     //var objectId = выбранная строка грида
    //     var gridmain = this.lookupReference('attachlistgrid');
    //     var selrow = gridmain.getSelectionModel().getSelection()[0];
    //     if (!selrow) return;
    //     var resSelected = gridmain.store.getByInternalId(selrow.internalId).data;
    //     if (!resSelected) return;
    //
    //     if (this.attach) {
    //         this.attach.close();
    //         this.attach = null;
    //     }
    //     if (!this.attach) {
    //         var me = this;
    //         var store = Ext.getStore('RefObjectsAll'); //глобальное хранилище, содержащее данные ведомости
    //         if (!store) return;
    //
    //         if (store.isLoaded()){
    //             me.attach = Ext.widget("attach", {object: {fileId: resSelected.id, objectId: resSelected.object_id, desc: resSelected.desc}});
    //             me.attach.setTitle("Изменить документ");
    //             me.attach.show();
    //         }else {
    //             store.load({
    //                 callback: function () {
    //                     me.attach = Ext.widget("attach", {object: {fileId: resSelected.id, objectId: resSelected.object_id, desc: resSelected.desc}});
    //                     me.attach.setTitle("Изменить документ");
    //                     me.attach.show();
    //                 }
    //             });
    //         }
    //
    //     }
    // },
    //
    // onDownloadClick: function () {
    //     var gridmain = this.lookupReference('attachlistgrid');
    //     var selrow = gridmain.getSelectionModel().getSelection()[0];
    //     if (!selrow) return;
    //     var resSelected = gridmain.store.getByInternalId(selrow.internalId).data;
    //     if (!resSelected) return;
    //     window.open(ProxyUrlBackend + '/attach_file/?id=' + resSelected.id + '&name=' + resSelected.name);
    // },
    //
    // onDelClick: function () {
    //     var gridmain = this.lookupReference('attachlistgrid');
    //     var selrow = gridmain.getSelectionModel().getSelection()[0];
    //     if (!selrow) return;
    //     var resSelected = gridmain.store.getByInternalId(selrow.internalId).data;
    //     if (!resSelected) return;
    //
    //     Ext.Ajax.request({
    //         url: ProxyUrlBackend + '/attach_file/?id=' + resSelected.id + '&name=' + resSelected.name,
    //         method: 'delete',
    //         scope: this,
    //         headers: {'Content-Type': 'application/json'},
    //         withCredentials: true,
    //         cors: true,
    //         useDefaultXhrHeader: false,
    //         success: function (response, options) {
    //             var jsonResp = Ext.util.JSON.decode(response.responseText);
    //             Ext.MessageBox.alert("Информация", "Документ успешно удален", function () {
    //                 gridmain.getStore().reload();
    //             }, this);
    //         },
    //         failure: function (response, options) {
    //             var mes;
    //             try {
    //                 var jsonResp = Ext.util.JSON.decode(response.responseText);
    //                 mes = jsonResp.message;
    //             } catch (e) {
    //                 mes = response.statusText;
    //             }
    //             Ext.Msg.alert("Ошибка", "При удалении документа возникла ошибка:<br/>" + mes);
    //         }
    //     });
    //
    // }



});
